# To-Do List App

A simple and interactive To-Do List application built using React.js. It allows users to add, delete, and mark tasks as completed while persisting tasks using localStorage.

## Features

- Add tasks
- Delete tasks
- Mark tasks as completed
- Data persists using localStorage
- Responsive design

## Installation

1. Clone the repository:
   ```sh
   git clone <repo-url>
   ```
2. Navigate to the project directory:
   ```sh
   cd todo-list-app
   ```
3. Install dependencies:
   ```sh
   npm install
   ```
4. Start the development server:
   ```sh
   npm start
   ```

## License

This project is open-source and free to use under the MIT License.
